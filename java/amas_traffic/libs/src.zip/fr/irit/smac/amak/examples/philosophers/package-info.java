/**
 * This package contains the example of the resolution of the philosopher's dinner
 */
package fr.irit.smac.amak.examples.philosophers;
