/**
 * This package contains various examples
 */
package fr.irit.smac.amak.examples;
