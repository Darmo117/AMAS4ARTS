package fr.irit.smac.amak.aid;

/**
 * The agent identifier object of a agent.
 */
public interface AID {

	String getID();

}
