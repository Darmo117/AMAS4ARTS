/**
 * This package contains some useful tools 
 */
package fr.irit.smac.amak.tools;
