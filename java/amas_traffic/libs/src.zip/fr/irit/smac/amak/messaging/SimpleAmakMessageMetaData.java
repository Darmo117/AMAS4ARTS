package fr.irit.smac.amak.messaging;

public class SimpleAmakMessageMetaData implements IAmakMessageMetaData {


}
