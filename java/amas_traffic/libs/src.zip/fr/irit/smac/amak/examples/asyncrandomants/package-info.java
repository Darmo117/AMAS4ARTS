/**
 * This package contains an example showing ants moving randomly.
 * In this example, agents are fully asynchronous.
 */
package fr.irit.smac.amak.examples.asyncrandomants;
