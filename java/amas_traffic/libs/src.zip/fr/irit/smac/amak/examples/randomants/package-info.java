/**
 * This package contains an example  showing ants moving randomly 
 */
package fr.irit.smac.amak.examples.randomants;
