/**
 * This package contains all the base classes of the framework
 */
package fr.irit.smac.amak;
