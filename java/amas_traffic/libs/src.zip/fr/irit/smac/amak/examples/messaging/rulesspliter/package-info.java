/**
 * Example with social agents using messages.
 */
/**
 * @author florent.mouysset
 *
 */
package fr.irit.smac.amak.examples.messaging.rulesspliter;