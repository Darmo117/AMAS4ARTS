/**
 * 
 */
/**
 * @author florent.mouysset
 *
 */
package fr.irit.smac.amak.messaging;