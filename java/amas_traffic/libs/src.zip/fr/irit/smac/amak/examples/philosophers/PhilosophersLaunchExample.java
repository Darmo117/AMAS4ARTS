package fr.irit.smac.amak.examples.philosophers;

public class PhilosophersLaunchExample {

	public static void main(String[] args) {
		
		
		TableExample env = new TableExample();
		new PhilosophersAMASExample(env);
		
		
	}

}
