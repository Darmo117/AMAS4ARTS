/**
 * This package contains all the classes related to the user interface
 */
package fr.irit.smac.amak.ui;
