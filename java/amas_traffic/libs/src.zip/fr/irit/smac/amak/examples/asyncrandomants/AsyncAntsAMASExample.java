package fr.irit.smac.amak.examples.asyncrandomants;

import fr.irit.smac.amak.Amas;
import fr.irit.smac.amak.Scheduling;

public class AsyncAntsAMASExample extends Amas<AsyncWorldExample> {

	public AsyncAntsAMASExample(AsyncWorldExample environment, Scheduling scheduling) {
		super(environment, scheduling);
	}

}
