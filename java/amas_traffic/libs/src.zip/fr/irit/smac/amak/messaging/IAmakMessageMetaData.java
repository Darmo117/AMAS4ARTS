package fr.irit.smac.amak.messaging;

public interface IAmakMessageMetaData {
}
