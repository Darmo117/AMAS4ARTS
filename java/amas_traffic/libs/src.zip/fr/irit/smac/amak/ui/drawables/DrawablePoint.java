package fr.irit.smac.amak.ui.drawables;

import fr.irit.smac.amak.ui.VUI;

public class DrawablePoint extends DrawableRectangle {

	public DrawablePoint(VUI vui, double dx, double dy) {
		super(vui, dx, dy, 10, 10);
	}

}
